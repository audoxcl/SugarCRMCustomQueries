<?php 

$app_strings['LBL_CUSTOM_QUERIES'] = 'Custom Queries';

?>