<?php

$entry_point_registry['CustomQueries'] = array('file' => 'custom/CustomQueries.php', 'auth' => true);
$entry_point_registry['CustomQueriesRemote'] = array('file' => 'custom/CustomQueries.php', 'auth' => false);
$entry_point_registry['getCSV'] = array('file' => 'custom/getCSV.php', 'auth' => false);

?>