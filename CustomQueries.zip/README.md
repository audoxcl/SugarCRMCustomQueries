# SugarCRMCustomQueries

This module has two main features:

1. To execute advanced queries directly in the instance database (like PhpMyAdmin)
2. To execute queries (from other apps) to your CRM via web services and receive data in JSON format

Documentation available here:
[www.sugarqueries.com](http://www.sugarqueries.com)

Download:
[Here you can download ZIP file ready to install in your CRM instance](https://github.com/audoxcl/SugarCRMCustomQueries/releases/latest/download/CustomQueries.zip)
